<body>
</br>
</br>
<div>
  <form action="select.php" method="post">
    <p><a href ="uploadFile.php"><span>
        <input type="button" value = "Upload Image Page"></span></a>
      <a href ="delete.php"><span>
        <input type="button" value = "Delete Image Page"></span></a></p>
  </form>


</body>
</br>
</br>
