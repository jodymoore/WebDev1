<!DOCTYPE html>
<html><head>  
      </head>     
    <body>
        <div id="footer">

         <div class="wrapper">

            <div class="jcarousel-wrapper">
            
                <div class="jcarousel">
                    <ul>
                        <li><img src="/public/img/K&NSeries.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/lfr.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/eibach.png"width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/sunriseLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/lucas.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/ARP.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/sunocoLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/moogLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/jegsLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/goodyearLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/msdLogo.png" width="200px" height="100px" alt=""></li>
                        <li><img src="/public/img/cometicLogo.png" width="200px" height="100px" alt=""></li>
                        
                    </ul>
                </div>
         

            </div>
        </div>
            <div id="bottom">
            <font color="white">Development and Design by Jody Moore &#9400;</font>
             <li><a href="/public/login.php">Admin</a></li>
            </div>

        </div>

    </body>

</html>