 <body class="news-bg">
<div id="middle">
     </br> 
     
       <div class="tw1">
<a class="twitter-timeline" href="https://twitter.com/colerouse2" height="500px" width="500px" data-chrome="nofooter" data-chrome="transparent" data-border-color="#a80000">Tweets by colerouse2</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
       </div>

</div>

  
  