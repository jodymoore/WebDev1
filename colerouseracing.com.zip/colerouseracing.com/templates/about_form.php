<body class="main-bg">
<br>
</br>

  <div class="col-sm-3 col-md-5 col-lg-3">
    <div class="dp-box">
        <img class="dp" src="/public/img/hero4.jpg" alt="">
    </div>
  </div>
					
<div class="col-sm-9 col-md-7 col-lg-9 abDiv">
  <p>
  Cole Rouse began racing at the I-44 Speedway in Lebanon, Missouri just a few years ago. Success came early though, as he went to victory lane driving<br> a Baby Grand Stock Car. From there on the now 17-year-old hotshoe was hooked and ready to move on to the next step.
  </p>
  <p>
  Rouse was tapped to pilot the No. 20 for famed racing legend Rick Turner and his Rick Turner Racing team. As a rookie in the JEGS/CRA All-Stars Tour Presented by Chevrolet Performance, he showed potential. Each race, as he gained experience, the results improved. By the end of the 2014 season the Arkansas teenager knew, driving race cars at the highest levels of motorsports was what he wanted to do.
  </p>
  <p>
    2015 saw a move to another No. 20. This time for chassis builder and crew chief Kevin Crider out of Missouri. The speed showed up almost instantly. Rouse has been competitive in almost every event he has run. A string of bad luck has kept the No. 20 Rouse Custom Homes Late Model out of victory lane but the team remains confident that their time is coming. Along with a very stout Late Model schedule, Rouse will look to make his debut in the ARCA Racing Series Presented by Menards later in the 2015 season.
  </p>
  <br>
</div>
</div>
</div>

