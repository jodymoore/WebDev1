<form action="team.php" method="post">
    <fieldset>
        <div class="form-group">
            <a  href="/"><img alt="team" src="/public/img/team.jpg"/></a>
        </div>

     </fieldset>
</form>
