             
<body class="main-bg">

              
  <div id="hero">         
   
   <a href="http://hometracks.nascar.com/nknps-west/race-central-live-evergreen">
  <img id="events" src= "/public/img/racesched2.jpg" >
</a> 
   
  

  </div>

  <div id="div2">
    <div id="pdiv">
      <p id="p1">
          Cole Rouse began racing at the I-44 Speedway in Lebanon, Missouri just a few years ago. 
       Success came early though, as he went to victory lane driving a 
       Baby Grand Stock Car. From there on the now 17-year-old hotshoe was hooked and ready to move on to the next step. 
      </p>
      <a href="/public/about.php"><font id="rm">Read More</font></a>
    </div> 
   
     
  

    <div>
        <a href="/public/gallery.php"><img id="img1" src= "/public/img/cover2.jpg"width="300px" height="200px"></a> 
        <iframe id="iframe1" src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FColeRouseRacing%2Fvideos%2F835341379916217%2F&show_text=0&width=560" width="300px" height="200px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true">
        </iframe>
    </div>
  </div>
  <div>
    <p class="social-buttons">
      <a class="btn btn-circle" href="https://www.facebook.com/ColeRouseRacing">
        <i class="fa fa-facebook">
          <img class="imgsc" src="/public/img/facebook.png">
        </i>
      </a>
      <a class="btn btn-circle" href="https://twitter.com/colerouse2">
        <i class="fa fa-twitter">
         <img class="imgsc" src="/public/img/twitter.png">
        </i>
      </a>
      <a class="btn btn-circle" href="https://www.instagram.com/_colerouse_/">
        <i class="fa fa-instagram">
         <img class="imgsc" src="/public/img/instagram.png">
        </i>
      </a>
   </p>
 </div>
</div>	

<br>
               
             
             
             
          
        
 