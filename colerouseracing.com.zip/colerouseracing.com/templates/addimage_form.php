<form enctype="multipart/form-data" action="addimage.php" method="POST">
 Please choose a file: <input name="file" type="file" /><br />
 <input type="submit" value="Upload" />
 </form>