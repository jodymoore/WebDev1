<body class="contact-bg">

<br>

<h1 class="text-center"><span class="page-heading">Contact Cole</span></h1>

<div class="row">
	<div class="col-sm-6">
		<form class="form-horizontal" method="post" action="/public/contactExecute.php">
			<fieldset>
            <div class="form-group">
			<label class="col-md-3 control-label" for="Name"><h4></h4></label>
			 <div class="col-md-9">
				<input id="Name" name="cf_name" type="text" placeholder="Your name" class="form-control">
				</div>
					</div>
									
					<!-- Email input-->
					<div class="form-group">
					<label class="col-md-3 control-label" for="email"><h4></h4></label>
					<div class="col-md-9">
						<input id="Email" name="cf_email" type="text" placeholder="Your email" class="form-control">
						</div>
					</div>
									
					<!-- Message body -->
					<div class="form-group">
					<label class="col-md-3 control-label" for="Message"><h4></h4></label>
					 <div class="col-md-9">
						<textarea class="form-control" id="Message" name="cf_message" placeholder="Please enter your message here..." rows="5"></textarea>
					</div>
				</div>
									
				<!-- Form actions -->
				<div class="form-group">
				<div class="col-md-12 text-right">
					<button type="submit" name="submit" class="btn btn-success btn-lg">Submit</button>
				</div>
			</div>
		 </fieldset>
		</form>
		</div>
	<div class="col-sm-6">	
	</div>
</div>

    <br>
    </br>
</div>