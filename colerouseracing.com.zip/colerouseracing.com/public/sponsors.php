<?php
   require("../includes/config.php");
      render("sponsors_form.php", [ "title" => "start"]); 
?>