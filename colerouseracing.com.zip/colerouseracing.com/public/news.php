<?php
   require("../includes/config.php");
      render("news_page.php", [ "title" => "start"]); 
?>
