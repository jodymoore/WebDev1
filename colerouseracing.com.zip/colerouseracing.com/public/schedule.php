<?php
    // configuration
   require("../includes/config.php");
   
    render("schedule_page.php", [ "title" => "buy"]);
?>
