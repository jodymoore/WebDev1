<?php
$connection = mysqli_connect('localhost','jody','groove','colerouseracing') or die(mysqli_error($connection));
?>