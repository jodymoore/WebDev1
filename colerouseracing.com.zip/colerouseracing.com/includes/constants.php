<?php

    /**
     * constants.php
     *
     * Computer Science 50
     * Final project
     *
     * Global constants.
     */

    // your database's name
    define("DATABASE", "colerouseracing");

    // your database's password
    define("PASSWORD", "groove");

    // your database's server
    define("SERVER", "localhost");

    // your database's username
    define("USERNAME", "jody");

?>
